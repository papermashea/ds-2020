////////////////////
//WEEK 06
////////////////////

// SQL CREATE DATABASE
CREATE TABLE aaTest1 (
    mtgday varchar(25), 
    mtgtime  varchar(25), 
    mtghour int, 
    mtglocation varchar(75), 
    mtgaddress varchar(75), 
    mtgregion varchar(75), 
    mtgtypes varchar(150)
);