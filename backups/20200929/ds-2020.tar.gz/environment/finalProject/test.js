const dotenv = require('dotenv');

dotenv.config();

console.log(process.env.TIK)
// console.log(process.env.API_KEY)